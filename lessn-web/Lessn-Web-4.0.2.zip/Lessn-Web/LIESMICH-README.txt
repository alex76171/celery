Lessn im Browser / Lessn in the browser  (Version 4.0.2)

DEUTSCH
1) Nur anschauen / KI / Kalender: Lessn.html doppelklicken. Läuft in jedem Browser.
   Der Login bei WebUntis und IServ wird vom Browser blockiert, solange die Datei direkt geöffnet ist.
2) Alles inklusive Schul-Login: Node.js installieren (https://nodejs.org, kostenlos), dann
   Windows: start-windows.bat doppelklicken  ·  Mac/Linux: ./start.sh
   Lessn öffnet sich unter http://localhost:8080. Das Fenster offen lassen, solange du Lessn benutzt.
   Auf dem Handy im selben WLAN: die Adresse aufrufen, die im Fenster angezeigt wird (http://192.168.x.x:8080).
Hinweis: Der kleine Server leitet nur Anfragen an deine Schule weiter und speichert nichts auf der Festplatte.
Alles andere (Hausaufgaben, Kalender, Chats, Einstellungen) bleibt im Browser.

ENGLISH
1) Just looking / AI / calendar: double-click Lessn.html. Works in any browser.
   Browsers block the WebUntis and IServ login while the file is opened directly.
2) Everything including the school login: install Node.js (https://nodejs.org, free), then
   Windows: double-click start-windows.bat  ·  Mac/Linux: ./start.sh
   Lessn opens at http://localhost:8080. Keep the window open while you use Lessn.
   On your phone in the same Wi-Fi: open the address shown in the window (http://192.168.x.x:8080).
The small server only passes requests to your school on and stores nothing on disk; everything else stays in the browser.

Not available in the browser (use the Android app or Lessn for Windows): lesson recording, notifications while the
tab is closed, Do Not Disturb, attendance check, IServ files, opening files in other apps, PC link.
