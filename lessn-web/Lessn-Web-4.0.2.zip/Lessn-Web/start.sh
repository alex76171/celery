#!/bin/sh
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Node.js is needed: https://nodejs.org"; exit 1; }
(sleep 1; (xdg-open http://localhost:8080 || open http://localhost:8080) >/dev/null 2>&1) &
node server.js --lan
