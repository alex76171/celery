@echo off
title Lessn
where node >nul 2>nul || (echo Node.js is needed: https://nodejs.org & start https://nodejs.org & pause & exit /b)
start "" http://localhost:8080
node "%~dp0server.js" --lan
pause
